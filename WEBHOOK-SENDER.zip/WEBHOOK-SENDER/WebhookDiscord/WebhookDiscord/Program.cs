﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace ConsoleApp1
{
    class Program
    {
        private static readonly List<string> WebhookUrls = new List<string>
        {
            "https://discord.com/api/webhooks/your-webhook-id-1/your-webhook-token-1",
            "https://discord.com/api/webhooks/your-webhook-id-2/your-webhook-token-2",
            "https://discord.com/api/webhooks/your-webhook-id-3/your-webhook-token-3",
            // Add more webhooks as needed
        };

        private static readonly List<string> Messages = new List<string>
        {
            "Hey everyone, how’s it going?",
            "Just saw an amazing movie last night!",
            "What’s everyone up to this weekend?",
            "Anyone have any good book recommendations?",
            "I’m looking for new music, any suggestions?",
            "Does anyone know a good place to eat around here?",
            "Just finished a new project at work, feeling good!",
            "Can someone help me with a quick question?",
            "What’s the latest news in your area?",
            "Does anyone want to catch up for coffee?",
            "I’m thinking about starting a new hobby. Any ideas?",
            "How’s the weather where you are?",
            "Got any exciting plans for the holidays?",
            "What’s the best TV show you’ve seen recently?",
            "Looking for a workout buddy. Any takers?",
            "Does anyone have a favorite recipe to share?",
            "Just bought a new gadget, can’t wait to try it out!",
            "What’s your favorite way to relax after a long day?",
            "Anyone have tips for staying productive?",
            "Just completed a personal milestone. Feeling great!",
            "Any fun games or apps you’d recommend?",
            "What’s your go-to comfort food?",
            "Does anyone have a favorite podcast?",
            "Looking for travel destination ideas. Any suggestions?",
            "How do you unwind after a stressful week?",
            "Anyone know a good workout routine for beginners?",
            "What’s your favorite thing to do on a rainy day?",
            "I’m planning a get-together. Who’s interested?",
            "What’s the most interesting thing you learned this week?",
            "Any recommendations for a good documentary?",
            "Does anyone have experience with home gardening?",
            "What’s your favorite book genre?",
            "I’m thinking of taking a class. Any recommendations?",
            "What’s the best advice you’ve ever received?",
            "Does anyone have a favorite local restaurant?",
            "Looking for a new series to binge-watch. Suggestions?",
            "What’s your favorite way to spend a day off?",
            "Any tips for maintaining a healthy work-life balance?",
            "What’s the most memorable trip you’ve ever taken?",
            "Looking for a new hobby. What’s yours?",
            "What’s the best thing about your week so far?",
            "Does anyone have a good tip for reducing stress?",
            "What’s your favorite way to stay motivated?",
            "How do you usually celebrate special occasions?",
            "Any fun activities planned for the weekend?",
            "What’s your favorite way to stay fit?",
            "Looking for recommendations on a good book to read.",
            "What’s something new you tried recently?",
            "How do you handle a challenging situation at work?",
            "What’s the best thing you’ve eaten recently?",
            "Anyone have a good tip for learning a new skill?",
            "What’s your favorite way to spend time with friends?",
            "Looking for advice on organizing my home office.",
            "What’s a hobby you’d like to pick up?",
            "How do you stay positive during tough times?",
            "Any cool gadgets or apps you’ve discovered recently?",
            "What’s the best part of your day usually?",
            "Does anyone have a favorite place to relax outdoors?",
            "What’s the most interesting thing you’ve read lately?",
            "How do you usually unwind after a busy day?",
            "Any recommendations for a great local event?"
        };

        static async Task Main(string[] args)
        {
            var httpClient = new HttpClient();
            var random = new Random();

            Console.WriteLine("Starting message sending. Press Ctrl+C to exit.");

            while (true)
            {
                var shuffledMessages = Messages.OrderBy(_ => random.Next()).ToList();
                var shuffledUrls = WebhookUrls.OrderBy(_ => random.Next()).ToList();

                foreach (var webhookUrl in shuffledUrls)
                {
                    var message = shuffledMessages[random.Next(shuffledMessages.Count)];
                    await SendMessageAsync(httpClient, webhookUrl, message);
                }
            }
        }

        private static async Task SendMessageAsync(HttpClient httpClient, string webhookUrl, string message)
        {
            var payload = new
            {
                content = message
            };

            var content = new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json");

            try
            {
                var response = await httpClient.PostAsync(webhookUrl, content);

                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine($"Sent message: \"{message}\" to {webhookUrl}");
                }
                else
                {
                    Console.WriteLine($"Failed to send message to {webhookUrl}. Status Code: {response.StatusCode}");
                    // Optionally retry here
                }
            }
            catch (HttpRequestException e)
            {
                Console.WriteLine($"Error sending message to {webhookUrl}: {e.Message}");
                // Optionally retry here
            }
        }
    }
}
